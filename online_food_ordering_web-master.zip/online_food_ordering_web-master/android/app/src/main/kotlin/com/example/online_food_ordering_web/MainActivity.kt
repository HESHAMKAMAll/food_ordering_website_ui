package com.example.online_food_ordering_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
